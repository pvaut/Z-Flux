#include "stdafx.h"
#include "3DScene.h"
#include "displaydevices.h"
#include "video.h"


int G_rendertype();

bool IsKeyDown(int virtkey);

//*********************************************************************
// T3DViewport
//*********************************************************************

T3DViewport::T3DViewport()
{
	videocapture=NULL;
	winxres=1;winyres=1;
	started=false;
	cosmos=&T3DCosmos::Get();
	addparam(_qstr("Scene"),SC_valname_string,true);

	camerapos=G_valuecontent<Tvertex>(&addparam(_qstr("CameraPos"),SC_valname_vertex)->content);
	cameradir=G_valuecontent<Tvector>(&addparam(_qstr("CameraDir"),SC_valname_vector)->content);
	cameraupdir=G_valuecontent<Tvector>(&addparam(_qstr("CameraUpDir"),SC_valname_vector)->content);
	enableusernavigation=addparam(_qstr("EnableUserNavigation"),SC_valname_boolean)->content.G_content_boolean();
	enableusertimecontrol=addparam(_qstr("EnableUserTimeControl"),SC_valname_boolean)->content.G_content_boolean();

	fadecolor=G_valuecontent<TSC_color>(&addparam(_qstr("FadeColor"),SC_valname_color)->content);
	fadecolor->copyfrom(0,0,0,0);

	usestereo=addparam(_qstr("UseStereo"),SC_valname_boolean)->content.G_content_boolean();
	usestereo->copyfrom(true);

	erasebackground=addparam(_qstr("EraseBackground"),SC_valname_boolean)->content.G_content_boolean();
	erasebackground->copyfrom(false);

	showcontrols=addparam(_qstr("ShowControls"),SC_valname_boolean)->content.G_content_boolean();

	framesize=addparam(_qstr("Framesize"),SC_valname_scalar)->content.G_content_scalar();
	framesize->copyfrom(0.005);


	transformation=G_valuecontent<Taffinetransformation>(&addparam(_qstr("Transf"),SC_valname_affinetransformation)->content);


//	addparam(_qstr("CameraPosFrame"),SC_valname_string);
//	addparam(_qstr("CameraLookAtFrame"),SC_valname_string);

	focaldistance=addparam(_qstr("FocalDistance"),SC_valname_scalar)->content.G_content_scalar();
	eyeseparation=addparam(_qstr("EyeSeparation"),SC_valname_scalar)->content.G_content_scalar();

	aperture=addparam(_qstr("Aperture"),SC_valname_scalar)->content.G_content_scalar();

	nearclipplane=addparam(_qstr("NearClipPlane"),SC_valname_scalar)->content.G_content_scalar();
	farclipplane=addparam(_qstr("FarClipPlane"),SC_valname_scalar)->content.G_content_scalar();

	stretchfactor=addparam(_qstr("StretchFactor"),SC_valname_scalar)->content.G_content_scalar();

	xoffsetfrac=addparam(_qstr("XOffsetFrac"),SC_valname_scalar)->content.G_content_scalar();

	addparam(_qstr("LeftDisplay"),SC_valname_string);
	addparam(_qstr("RightDisplay"),SC_valname_string);

	xminfrac=addparam(_qstr("XMinFrac"),SC_valname_scalar)->content.G_content_scalar();
	yminfrac=addparam(_qstr("YMinFrac"),SC_valname_scalar)->content.G_content_scalar();
	xmaxfrac=addparam(_qstr("XMaxFrac"),SC_valname_scalar)->content.G_content_scalar();
	ymaxfrac=addparam(_qstr("YMaxFrac"),SC_valname_scalar)->content.G_content_scalar();

	xmaxfrac->copyfrom(1.0);
	ymaxfrac->copyfrom(1.0);
	
	


	//generate unique, default name
	QString nm,nm0;
	int nr=0;
	while (true)
	{
		nr++;
		nm="Viewport_";nm+=QString(nr);
		bool found=false;
		for (int i=0; i<cosmos->G_viewportcount(); i++)
		{
			cosmos->G_viewport(i)->G_name(nm0);
			if (qstricmp(nm,nm0)==0) found=true;
		}
		if (!found) break;
	}
	param_setvalue(ObjNameStr,nm);

	leftwin=NULL;
	rightwin=NULL;

	resetparams();
}

void T3DViewport::resetparams()
{
	camerapos->copyfrom(Tvector(-1,0,0));
	cameradir->copyfrom(Tvertex(1,0,0));
	cameraupdir->copyfrom(Tvertex(0,1,0));
	enableusernavigation->copyfrom(false);
	enableusertimecontrol->copyfrom(false);

	focaldistance->copyfrom(7.0);
	eyeseparation->copyfrom(0.25);
	aperture->copyfrom(3.1415927/4);
	nearclipplane->copyfrom(0.1);
	farclipplane->copyfrom(100);
	stretchfactor->copyfrom(1.0);

	resetcurrentmove();
}


void T3DViewport::resetcurrentmove()
{
	currentmove.scenerot=Tvector(0,0,0);
	currentmove.cammove=Tvector(0,0,0);
}


void T3DViewport::applycurrentmove()
{
/*	scene_rotatehor(currentmove.scenerotx);
	scene_rotatevert(currentmove.sceneroty);
	camera_rotatehor(currentmove.camrotx);
	camera_rotatevert(currentmove.camroty);
	camera_move(currentmove.cammove);*/

	double distunit=G_focaldistance();

	Tvector dirx,diry,dirz;

	dirx.vecprod(cameradir,cameraupdir);dirx.normfrom(&dirx);
	diry.vecprod(&dirx,cameradir);diry.normfrom(&diry);
	dirz.normfrom(cameradir);

	camerapos->lincombfrom(1,camerapos,distunit*currentmove.cammove.G_x(),&dirx);
	camerapos->lincombfrom(1,camerapos,distunit*currentmove.cammove.G_y(),&diry);
	camerapos->lincombfrom(1,camerapos,distunit*currentmove.cammove.G_z(),&dirz);

	Tvector rotdir;

	rotdir.lincombfrom(1,&rotdir,currentmove.scenerot.G_x(),&dirx);
	rotdir.lincombfrom(1,&rotdir,currentmove.scenerot.G_y(),&diry);
	rotdir.lincombfrom(1,&rotdir,currentmove.scenerot.G_z(),&dirz);

	double angle=currentmove.scenerot.G_size();
	cameradir->rotatefrom(cameradir,&rotdir,angle);
	cameraupdir->rotatefrom(cameraupdir,&rotdir,angle);

	Tvector cpos;cpos.subtrvertices(camerapos,&Tvertex(0,0,0));
	cpos.rotatefrom(&cpos,&rotdir,angle);
	camerapos->copyfrom(cpos);
}


T3DViewport::~T3DViewport()
{
	if (videocapture!=NULL) delete videocapture;
	delfromscene();
	if (leftwin!=NULL) delete leftwin;
	if (rightwin!=NULL) delete rightwin;
}


void T3DViewport::G_sourcecodename(QString &str)
{ 
	QString str2;
	str=_qstr("root.Viewports.");
	G_name(str2);str+=str2;
}


bool T3DViewport::G_param_optionlist(StrPtr paramname, Tarray<QString> &list)
{
	return false;
}

void T3DViewport::paramchanged(StrPtr iname)
{
}

TObjectTreeItem* T3DViewport::G_parent()
{
	return cosmos->G_viewportlist();
}

void T3DViewport::start()
{
	RECT bbox,drect,rc;
	bool shareddevice;

	if (started) throw QError(_text("Viewport is already started"));

	StrPtr leftdisplayname=G_param(_qstr("LeftDisplay"))->content.G_content_string()->G_string();
	StrPtr rightdisplayname=G_param(_qstr("RightDisplay"))->content.G_content_string()->G_string();
	isstereo=(qstrlen(rightdisplayname)>0);

	if (!usestereo->G_val()) isstereo=false;

	if (G_rendertype()==RenderSingle)
	{//do not create render windows here: a single render window is owned by the display window
		StrPtr leftdisplayname=G_param(_qstr("LeftDisplay"))->content.G_content_string()->G_string();
		TDisplayDevice *leftdisplay=TDisplayAdapterlist::Get().G_device(leftdisplayname);
		if (leftdisplay==NULL) throw QError(_text("Could not find left display device"));
		if (leftdisplay->G_win()==NULL) throw QError(_text("Could not find left display device window"));
		leftdisplay->G_win()->initrenderwindow();

		leftdisplay->G_win()->GetClientRect(&rc);
		winxres=rc.right-rc.left;
		winyres=rc.bottom-rc.top;
		if (isstereo) winxres/=2;

		started=true;
		return;
	}

	double xminfr=xminfrac->G_val();
	double xmaxfr=xmaxfrac->G_val();
	double yminfr=yminfrac->G_val();
	double ymaxfr=ymaxfrac->G_val();
	double xminfr2,xmaxfr2,yminfr2,ymaxfr2;

	if (leftwin=NULL) delete leftwin;leftwin=NULL;
	if (rightwin!=NULL) delete rightwin;rightwin=NULL;

	shareddevice=(qstricmp(leftdisplayname,rightdisplayname)==0);

	TDisplayDevice *leftdisplay=TDisplayAdapterlist::Get().G_device(leftdisplayname);

	leftdisplay->G_win()->GetClientRect(&rc);
	winxres=rc.right-rc.left;
	winyres=rc.bottom-rc.top;


	if (leftdisplay==NULL) throw QError(_text("Could not find left display device"));
	if (leftdisplay->G_win()==NULL) throw QError(_text("Left display device is not yet started"));
	leftdisplay->G_displayrect(drect);
	xminfr2=xminfr;xmaxfr2=xmaxfr;yminfr2=yminfr;ymaxfr2=ymaxfr;
	if (shareddevice)
	{
		xminfr2=xminfr*0.5;xmaxfr2=xmaxfr*0.5;
	}
	bbox.left=  (int)(0.5+drect.left+xminfr2*(drect.right-drect.left));
	bbox.top=   (int)(0.5+drect.top+yminfr2*(drect.bottom-drect.top));
	bbox.right= (int)(0.5+drect.left+xmaxfr2*(drect.right-drect.left));
	bbox.bottom=(int)(0.5+drect.top+ymaxfr2*(drect.bottom-drect.top));
	leftwin=new TRenderWindow(false,leftdisplay);
	leftwin->createwin(bbox);
	leftwin->setup();

	if (isstereo)
	{
		xminfr2=xminfr;xmaxfr2=xmaxfr;yminfr2=yminfr;ymaxfr2=ymaxfr;
		if (shareddevice)
		{
			xminfr2=0.5+xminfr*0.5;xmaxfr2=0.5+xmaxfr*0.5;
		}
		TDisplayDevice *rightdisplay=TDisplayAdapterlist::Get().G_device(rightdisplayname);
		if (rightdisplay==NULL) throw QError(_text("Could not find left display device"));
		if (rightdisplay->G_win()==NULL) throw QError(_text("Right display device is not yet started"));
		bbox.left=  (int)(0.5+drect.left+xminfr2*(drect.right-drect.left));
		bbox.top=   (int)(0.5+drect.top+yminfr2*(drect.bottom-drect.top));
		bbox.right= (int)(0.5+drect.left+xmaxfr2*(drect.right-drect.left));
		bbox.bottom=(int)(0.5+drect.top+ymaxfr2*(drect.bottom-drect.top));
		rightwin=new TRenderWindow(true,rightdisplay);
		rightwin->createwin(bbox);
		rightwin->setup();
	}

	if (isstereo) wglShareLists(leftwin->rc,rightwin->rc);
	started=true;
}


TRenderWindow* T3DViewport::G_leftwin() { return leftwin; }
TRenderWindow* T3DViewport::G_rightwin() { return rightwin; }


StrPtr T3DViewport::G_attachedscenename()
{
	return  G_paramstring(_qstr("Scene"));
}

void T3DViewport::delfromscene()
{
	StrPtr scenename=G_attachedscenename();
	T3DScene *scene=G_3DCosmos().G_scene(scenename);
	if (scene!=NULL) scene->delattachedviewport(this);
	G_param(_qstr("Scene"))->content.fromstring(_qstr(""));
}


void T3DViewport::setscene(T3DScene *iscene)
{
	delfromscene();
	iscene->attachviewport(this);
	QString str;
	iscene->G_name(str);
	G_param(_qstr("Scene"))->content.fromstring(str);
}


double T3DViewport::G_eyeseparation()
{ 
	if (!G_isstereo()) return 0.0;
	return eyeseparation->G_val();
}


double T3DViewport::G_aspectratio()
{
	double screenratio=(winxres*(xmaxfrac->G_val()-xminfrac->G_val())*1.0/(winyres*(ymaxfrac->G_val()-yminfrac->G_val())))/G_stretchfactor();
	return screenratio;
}


void T3DViewport::camera_rotatehor(double angle)
{
	Tvector hordir,rotdir;
	hordir.vecprod(cameradir,cameraupdir);
	rotdir.vecprod(&hordir,cameradir);
	if (rotdir.G_size()<0.00001) return;
	rotdir.normfrom(&rotdir);
	cameradir->rotatefrom(cameradir,&rotdir,angle);
	cameraupdir->rotatefrom(cameraupdir,&rotdir,angle);
}

void T3DViewport::camera_rotatevert(double angle)
{
	Tvector rotdir;
	rotdir.vecprod(cameradir,cameraupdir);
	if (rotdir.G_size()<0.00001) return;
	rotdir.normfrom(&rotdir);
	cameradir->rotatefrom(cameradir,&rotdir,angle);
	cameraupdir->rotatefrom(cameraupdir,&rotdir,angle);
}

void T3DViewport::camera_move(double fc)
{
	camerapos->lincombfrom(1,camerapos,fc*G_cameramovestep(),cameradir);
}


void T3DViewport::scene_rotatehor(double angle)
{
	Tvector rotdir=*cameraupdir;
	rotdir.normfrom(&rotdir);
	cameradir->rotatefrom(cameradir,&rotdir,angle);
	cameraupdir->rotatefrom(cameraupdir,&rotdir,angle);
	Tvertex rotcenter(0,0,0);
	Tvector camerapsd;
	camerapsd.subtrvertices(camerapos,&rotcenter);
	camerapsd.rotatefrom(&camerapsd,&rotdir,angle);
	camerapos->add(&rotcenter,&camerapsd);
}

void T3DViewport::scene_rotatevert(double angle)
{
	double ang2=Tvector::angle(cameradir,cameraupdir);
	if ((angle>0)&&(ang2-angle<0.01)) return;
	if ((angle<0)&&(ang2-angle>Pi-0.01)) return;

	Tvector rotdir;
	rotdir.vecprod(cameradir,cameraupdir);
	if (rotdir.G_size()<0.00001) return;
	rotdir.normfrom(&rotdir);
	cameradir->rotatefrom(cameradir,&rotdir,angle);
//	cameraupdir->rotatefrom(cameraupdir,&rotdir,angle);
	Tvertex rotcenter(0,0,0);
	Tvector camerapsd;
	camerapsd.subtrvertices(camerapos,&rotcenter);
	camerapsd.rotatefrom(&camerapsd,&rotdir,angle);
	camerapos->add(&rotcenter,&camerapsd);
}

void T3DViewport::scene_move(double fc)
{
	Tvertex rotcenter(0,0,0);
	Tvector camerapsd;
	camerapsd.subtrvertices(camerapos,&rotcenter);
	camerapsd.mulfrom(&camerapsd,fc);
	camerapos->add(&rotcenter,&camerapsd);
}


void T3DViewport::switchcursoractive()
{
	T3DScene *scene=G_3DCosmos().G_scene(G_attachedscenename());
	if (scene!=NULL)
	{
		Tvertex cursorpos;
		cursorpos.lincombfrom(1.0,camerapos,G_focaldistance(),cameradir);
		double cursorsize=G_focaldistance()/10.0;
		scene->switch_cursoractive(cursorpos,cursorsize);
	}
}

bool T3DViewport::G_cursoractive()
{
	T3DScene *scene=G_3DCosmos().G_scene(G_attachedscenename());
	if (scene!=NULL) return scene->G_cursoractive();
	else return false;
}



void T3DViewport::dispatchusernavigation()
{
	T3DScene *scene=G_3DCosmos().G_scene(G_attachedscenename());

	if ((scene!=NULL)&&(scene->G_cursoractive()))
	{
		Tvector horzdir,vertdir,cdir;
		horzdir.vecprod(cameradir,cameraupdir);
		horzdir.normfrom(&horzdir);
		vertdir.vecprod(&horzdir,cameradir);
		vertdir.normfrom(&vertdir);
		cdir.normfrom(cameradir);
		if (G_3DCosmos().G_axisactive(UIA_X,2))
		{
			horzdir.mulfrom(&horzdir,G_3DCosmos().G_axisposit(UIA_X,2)*G_focaldistance()/100.0);
			scene->cursor_move(horzdir);
		}
		if (G_3DCosmos().G_axisactive(UIA_Y,2))
		{
			vertdir.mulfrom(&vertdir,G_3DCosmos().G_axisposit(UIA_Y,2)*G_focaldistance()/100.0);
			scene->cursor_move(vertdir);
		}
		if (G_3DCosmos().G_axisactive(UIA_Z,2))
		{
			cdir.mulfrom(&cdir,G_3DCosmos().G_axisposit(UIA_Z,2)*G_focaldistance()/100.0);
			scene->cursor_move(cdir);
		}
	}

	if (G_enableusernavigation())
	{
		double rotunit=0.02;

		if (G_3DCosmos().G_axisactive(UIA_X,UIL_0)) camera_rotatehor(-G_3DCosmos().G_axisposit(UIA_X,UIL_0)*rotunit);
		if (G_3DCosmos().G_axisactive(UIA_Y,UIL_0)) camera_rotatevert(G_3DCosmos().G_axisposit(UIA_Y,UIL_0)*rotunit);
		if (G_3DCosmos().G_axisactive(UIA_Z,UIL_0)) camera_move(G_3DCosmos().G_axisposit(UIA_Z,UIL_0));

		if (G_3DCosmos().G_axisactive(UIA_X,UIL_1)) scene_rotatehor(G_3DCosmos().G_axisposit(UIA_X,UIL_1)*rotunit);
		if (G_3DCosmos().G_axisactive(UIA_Y,UIL_1)) scene_rotatevert(-G_3DCosmos().G_axisposit(UIA_Y,UIL_1)*rotunit);
		if (G_3DCosmos().G_axisactive(UIA_Z,UIL_1)) scene_move(G_3DCosmos().G_axisposit(UIA_Z,UIL_1));
	}

	if ((G_enableusertimecontrol())&&(!G_cursoractive()))
	{
		if (G_3DCosmos().G_axisactive(UIA_Y,UIL_2)) G_3DCosmos().modify_timespeed(1+0.02*G_3DCosmos().G_axisposit(UIA_Y,UIL_2));
	}

}

void T3DViewport::switchstereo()
{
	usestereo->copyfrom(!usestereo->G_val());
	isstereo=usestereo->G_val();
}

void T3DViewport::videocapture_start(StrPtr ifilename)
{
	if (videocapture!=NULL) throw QError(_text("Video capture is already busy"));

	StrPtr leftdisplayname=G_param(_qstr("LeftDisplay"))->content.G_content_string()->G_string();
	TDisplayDevice *displaydevice=TDisplayAdapterlist::Get().G_device(leftdisplayname);
	if (displaydevice==NULL) throw QError(_text("No display device present"));
	TDisplayWindow *dispwin=displaydevice->G_win();
	if (dispwin==NULL) throw QError(_text("No display window present"));
	if (dispwin->renderwindow==NULL) throw QError(_text("No render window associated to display window"));
	videocapture=new Tvideocapture;
	videocapture->start(dispwin->renderwindow,ifilename);
}

void T3DViewport::videocapture_stop()
{
	if (videocapture==NULL) throw QError(_text("No video capture is busy"));
	videocapture->stop();
	delete videocapture;
	videocapture=NULL;
}

void T3DViewport::videocapture_addframe()
{
	if (videocapture!=NULL)
		videocapture->addframe();
}



///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_viewport_create,addviewport)
{
	setclasspath_fromtype(SC_valname_viewport);
	setreturntype(SC_valname_viewport);
	addvar(_qstr("XMinFrac"),SC_valname_scalar);
	addvar(_qstr("YMinFrac"),SC_valname_scalar);
	addvar(_qstr("XMaxFrac"),SC_valname_scalar);
	addvar(_qstr("YMaxFrac"),SC_valname_scalar);
	addvar(_qstr("LeftDisplay"),SC_valname_string);
	addvar(_qstr("RightDisplay"),SC_valname_string,false);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DViewport *vp=G_3DCosmos().G_viewportlist()->addviewport();

	vp->G_param(_qstr("XMinFrac"))->content.copyfrom(arglist->get(0)->G_content_scalar()->G_val());
	vp->G_param(_qstr("YMinFrac"))->content.copyfrom(arglist->get(1)->G_content_scalar()->G_val());
	vp->G_param(_qstr("XMaxFrac"))->content.copyfrom(arglist->get(2)->G_content_scalar()->G_val());
	vp->G_param(_qstr("YMaxFrac"))->content.copyfrom(arglist->get(3)->G_content_scalar()->G_val());

	vp->G_param(_qstr("LeftDisplay"))->content.fromstring(arglist->get(4)->G_content_string()->G_string());
	if (arglist->G_ispresent(5)) vp->G_param(_qstr("RightDisplay"))->content.fromstring(arglist->get(5)->G_content_string()->G_string());

	retval->encapsulate(vp);
}
ENDFUNCTION(func_viewport_create)


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_viewport_start,start)
{
	setmemberfunction(SC_valname_viewport);
//	addvar(_qstr("type"),SC_valname_string);
//	addvar(_qstr("name"),SC_valname_string);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DViewport *vp=G_valuecontent<T3DViewport>(owner);
	vp->start();
}
ENDFUNCTION(func_viewport_start)


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_viewport_aspectratio,aspectratio)
{
	setmemberfunction(SC_valname_viewport);
	setreturntype(SC_valname_scalar);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DViewport *vp=G_valuecontent<T3DViewport>(owner);
	retval->G_content_scalar()->copyfrom(vp->G_aspectratio());
}
ENDFUNCTION(func_viewport_aspectratio)


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_viewport_setscene,setscene)
{
	setmemberfunction(SC_valname_viewport);
	addvar(_qstr("scene"),SC_valname_scene);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DViewport *vp=G_valuecontent<T3DViewport>(owner);
	vp->setscene(G_valuecontent<T3DScene>(arglist->get(0)));
}
ENDFUNCTION(func_viewport_setscene)


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_viewport_startrecord,StartRecording)
{
	setmemberfunction(SC_valname_viewport);
	addvar(_qstr("filename"),SC_valname_string);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DViewport *vp=G_valuecontent<T3DViewport>(owner);
	StrPtr filename=arglist->get(0)->G_content_string()->G_string();
	vp->videocapture_start(filename);
}
ENDFUNCTION(func_viewport_startrecord)

///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_viewport_stoprecord,StopRecording)
{
	setmemberfunction(SC_valname_viewport);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DViewport *vp=G_valuecontent<T3DViewport>(owner);
	vp->videocapture_stop();
}
ENDFUNCTION(func_viewport_stoprecord)
