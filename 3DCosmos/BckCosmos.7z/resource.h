//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by 3DCosmos.rc
//
#define IDC_MYICON                      2
#define IDD_MY3DCOSMOS_DIALOG           102
#define IDD_SETTINGS                    102
#define IDS_APP_TITLE                   103
#define IDD_ABOUTBOX                    103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDI_MY3DCOSMOS                  107
#define IDI_SMALL                       108
#define IDC_MY3DCOSMOS                  109
#define IDR_MAINFRAME                   128
#define IDB_ROUNDCORNER                 129
#define IDB_SCROLLDOWN                  130
#define IDB_SCROLLEFT                   131
#define IDB_SCROLLRIGHT                 132
#define IDB_SCROLLUP                    133
#define IDB_STOP                        134
#define IDB_ADD                         135
#define IDB_PROCEED                     136
#define IDB_PROCEEDALL                  137
#define IDB_SAVE                        138
#define IDB_LOAD                        139
#define IDB_NEW                         140
#define IDB_CLOSEFILE                   141
#define IDD_SEARCH                      141
#define IDB_UNDO                        142
#define IDB_REDO                        143
#define IDB_CLIPBOARD_COPY              144
#define IDD_EDITTEXT                    144
#define IDB_CLIPBOARD_PASTE             145
#define IDB_ANIMATE                     146
#define IDB_SEARCH                      147
#define IDB_SETTINGS                    148
#define IDB_BACK                        149
#define IDB_FORWARD                     150
#define IDC_SCRIPTSDIR                  1002
#define IDC_BUTTON1                     1003
#define IDC_BUTTON2                     1004
#define IDC_COLORSCHEME                 1005
#define IDC_EDIT1                       1006
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NO_MFC                     1
#define _APS_NEXT_RESOURCE_VALUE        145
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
