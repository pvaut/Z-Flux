#include "stdafx.h"

#include "vecmath.h"
#include "vec_transformation.h"

#include "sc_script.h"

#include "3DScene.h"
#include "3DControls.h"

#include "gl/gl.h"
#include "gl/glu.h"
#include "gl/glaux.h"

/////////////////////////////////////////////////////////////
// T3DControl
/////////////////////////////////////////////////////////////

T3DControl::T3DControl(T3DScene *iscene, bool addtocontrols) : T3DObject(iscene)
{
	position=G_valuecontent<Tvertex>(&addparam(_qstr("Position"),SC_valname_vertex)->content);

	sizeunit=addparam(_qstr("Size"),SC_valname_scalar)->content.G_content_scalar();
	sizeunit->copyfrom(0.05);

	color=G_valuecontent<TSC_color>(&addparam(_qstr("Color"),SC_valname_color)->content);
	color->copyfrom(1,1,1,1);
	if (addtocontrols) G_3DCosmos().controls_add(this);

	wasmodified=addparam(_qstr("WasModified"),SC_valname_boolean)->content.G_content_boolean();
	wasmodified->copyfrom(false);

}


T3DControl::~T3DControl()
{
	G_3DCosmos().controls_del(this);
}


void T3DControl::precalcrender(Tprecalcrendercontext *pre)
{
	if (!G_isvisible()) return;
	ASSERT(parentframe!=NULL);
	rendercolor=*color;
	if (pre->parentsubframe!=NULL)
		rendercolor.mulwith(pre->parentsubframe->G_rendercolor());
}

bool T3DControl::G_isactive()
{
	return G_3DCosmos().G_activecontrol()==this;
}

void T3DControl::render(Trendercontext *rc, const TObjectRenderStatus *status, bool isrecording)
{
	if (!G_isvisible()) return;
	if (!rc->G_viewport()->G_showcontrols()) return;
	if (!G_3DCosmos().G_showcontrols()) return;

	double x0=position->G3_x();
	double y0=position->G3_y();
	double sx=G_controlsizex();
	double sy=G_controlsizey();

	rc->enablelight(status->enablelight);
	rc->SetBlendType(status->currentobjectblendtype);
	rc->EnableDepthMask(status->currentobjectdepthmask!=DepthMaskDisable);
	rc->EnableDepthTest(status->currentobjectdepthtest!=DepthTestDisable);


	if ((G_canselect())&&(G_isactive()))
	{
		glColor4d(1.0,0.0,0.0,1.0);
		render_frame(x0-G_textsize()/5,y0-G_textsize()/5,sx+2*G_textsize()/5,sy+2*G_textsize()/5,G_offset());
	}
	glColor4d(color->G_R(),color->G_G(),color->G_B(),color->G_A());
	render_impl(rc,status);
}

double T3DControl::G_textsize()
{
	return 0.8*G_sizeunit();
}

double T3DControl::G_offset()
{
	return 0.01*G_sizeunit();
}

void T3DControl::render_rect(double x0, double y0, double lx, double ly, double z0)
{
	glBegin(GL_QUADS);
	glVertex3d(x0,y0,z0);
	glVertex3d(x0+lx,y0,z0);
	glVertex3d(x0+lx,y0+ly,z0);
	glVertex3d(x0,y0+ly,z0);
	glEnd();
}

void T3DControl::render_frame(double x0, double y0, double lx, double ly, double z0)
{
	glLineWidth(2.0f);
	glBegin(GL_LINE_LOOP);
	glVertex3d(x0,y0,z0);
	glVertex3d(x0+lx,y0,z0);
	glVertex3d(x0+lx,y0+ly,z0);
	glVertex3d(x0,y0+ly,z0);
	glEnd();
}




/////////////////////////////////////////////////////////////
// T3DControl_Frame
/////////////////////////////////////////////////////////////


T3DControl_Frame::T3DControl_Frame(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	sizex=addparam(_qstr("SizeX"),SC_valname_scalar)->content.G_content_scalar();
	sizey=addparam(_qstr("SizeY"),SC_valname_scalar)->content.G_content_scalar();

/*	color->Set_R(0.15);
	color->Set_G(0.15);
	color->Set_B(0.15);*/
}

T3DControl_Frame::~T3DControl_Frame()
{
}


double T3DControl_Frame::G_controlsizex()
{
	return sizex->G_val();
}

double T3DControl_Frame::G_controlsizey()
{
	return sizey->G_val();
}




void T3DControl_Frame::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=0;
	double sx=G_controlsizex();
	double sy=G_controlsizey();

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	render_rect(x0,y0,sx,sy,z0);
}



/////////////////////////////////////////////////////////////
// T3DControl_Text
/////////////////////////////////////////////////////////////


T3DControl_Text::T3DControl_Text(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	content=addparam(_qstr("Content"),SC_valname_string)->content.G_content_string();
}

T3DControl_Text::~T3DControl_Text()
{
}


double T3DControl_Text::G_controlsizex()
{
	return 0.0;
}

double T3DControl_Text::G_controlsizey()
{
	return G_sizeunit();
}




void T3DControl_Text::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=G_offset();
	double sy=G_sizeunit();


	QString str;
	content->tostring(str,0);
	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	rc->rendertext(DEFAULT_FONT,&Tvertex(x0,y0+sy/4,z0),
		&Tvector(G_textsize(),0,0),
		&Tvector(0,G_textsize(),0),str,0);
}



/////////////////////////////////////////////////////////////
// T3DControl_Scalar
/////////////////////////////////////////////////////////////


T3DControl_Scalar::T3DControl_Scalar(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	sizex=addparam(_qstr("SizeX"),SC_valname_scalar)->content.G_content_scalar();
	rangesizex=addparam(_qstr("RangeSizeX"),SC_valname_scalar)->content.G_content_scalar();

	value=addparam(_qstr("Value"),SC_valname_scalar)->content.G_content_scalar();
	vmin=addparam(_qstr("Min"),SC_valname_scalar)->content.G_content_scalar();vmin->copyfrom(0.0);
	vmax=addparam(_qstr("Max"),SC_valname_scalar)->content.G_content_scalar();vmax->copyfrom(100.0);
	vstep=addparam(_qstr("Step"),SC_valname_scalar)->content.G_content_scalar();vstep->copyfrom(2.0);
	decimalcount=addparam(_qstr("DecimalCount"),SC_valname_scalar)->content.G_content_scalar();
}

T3DControl_Scalar::~T3DControl_Scalar()
{
}


double T3DControl_Scalar::G_controlsizex()
{
	return sizex->G_val()+rangesizex->G_val();
}

double T3DControl_Scalar::G_controlsizey()
{
	return G_sizeunit();
}


void T3DControl_Scalar::checkrange()
{
	double vl=value->G_val();
	double minvl=vmin->G_val();
	double maxvl=vmax->G_val();
	if (vl>maxvl) vl=maxvl;
	if (vl<minvl) vl=minvl;
	value->copyfrom(vl);
}

void T3DControl_Scalar::addstep(double stepcount)
{
	value->copyfrom(value->G_val()+stepcount*vstep->G_val());
	checkrange();
	Set_wasmodified();
}


bool T3DControl_Scalar::UI_OnPressed_Up()
{
	addstep(+1.0);
	return true;
}

bool T3DControl_Scalar::UI_OnPressed_Down()
{
	addstep(-1.0);
	return true;
}


bool T3DControl_Scalar::UI_OnKeyDown(UINT ch, bool shiftpressed, bool controlpressed)
{
	return false;
}

bool T3DControl_Scalar::UI_OnChar(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch=='+')
	{
		addstep(+1.0);
		return true;
	}
	if (ch=='-')
	{
		addstep(-1.0);
		return true;
	}
	return false;
}


void T3DControl_Scalar::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=G_offset();
	double sx=sizex->G_val();
	double sy=G_sizeunit();

	double vl=value->G_val();
	int digitcount=decimalcount->G_intval();

	TCHAR formatstr[100];
	CString str;
	_stprintf_s(formatstr,99,_qstr("%%0.%dlf"),digitcount);
	str.Format(formatstr,vl);

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	rc->rendertext(DEFAULT_FONT,&Tvertex(x0+sy/10,y0+sy/4,z0),
		&Tvector(G_textsize(),0,0),
		&Tvector(0,G_textsize(),0),str,0);

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	render_frame(x0,y0,sx,sy,z0+G_offset());

	//draw range
	x0=G_controlposx()+sizex->G_val()+G_sizeunit()/5;
	y0=y0+sy/2;
	sx=rangesizex->G_val()-G_sizeunit()/5;
	if (sx>0)
	{
		double x1=sx*(value->G_val()-vmin->G_val())/(vmax->G_val()-vmin->G_val());
		if (x1<0) x1=0;if (x1>sx) x1=sx;
		x1+=x0;
		glLineWidth(2.0f);
		glBegin(GL_LINES);
		glVertex3d(x0,y0,z0);
		glVertex3d(x0+sx,y0,z0);
		glVertex3d(x1,y0-sy/4,z0);
		glVertex3d(x1,y0+sy/4,z0);
		glEnd();
	}

}


void T3DControl_Scalar::paramchanged(StrPtr iname)
{
	checkrange();
}


/////////////////////////////////////////////////////////////
// T3DControl_Edit
/////////////////////////////////////////////////////////////


T3DControl_Edit::T3DControl_Edit(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	sizex=addparam(_qstr("SizeX"),SC_valname_scalar)->content.G_content_scalar();

	content=addparam(_qstr("Content"),SC_valname_string)->content.G_content_string();
}

T3DControl_Edit::~T3DControl_Edit()
{
}


double T3DControl_Edit::G_controlsizex()
{
	return sizex->G_val();
}

double T3DControl_Edit::G_controlsizey()
{
	return G_sizeunit();
}


bool T3DControl_Edit::UI_OnKeyDown(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch==VK_BACK)
	{
		QString str;
		content->tostring(str,0);
		str.substring(0,str.G_length()-2);
		content->fromstring(str);
		Set_wasmodified();
		return true;
	}
	return false;
}

bool T3DControl_Edit::UI_OnChar(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch>=31)
	{
		QString str;
		content->tostring(str,0);
		str+=ch;
		content->fromstring(str);
		Set_wasmodified();
		return true;
	}
	return false;
}


void T3DControl_Edit::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=G_offset();
	double sx=sizex->G_val();
	double sy=G_sizeunit();


	QString str;
	str=content->G_string();
	if (G_isactive())
		str+=_qstr("|");
	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	rc->rendertext(DEFAULT_FONT,&Tvertex(x0+sy/10,y0+sy/4,z0),
		&Tvector(G_textsize(),0,0),
		&Tvector(0,G_textsize(),0),str,0);

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	render_frame(x0,y0,sx,sy,z0+G_offset());
}


void T3DControl_Edit::paramchanged(StrPtr iname)
{
}



/////////////////////////////////////////////////////////////
// T3DControl_Check
/////////////////////////////////////////////////////////////


T3DControl_Check::T3DControl_Check(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	checked=addparam(_qstr("Checked"),SC_valname_boolean)->content.G_content_boolean();
}

T3DControl_Check::~T3DControl_Check()
{
}


double T3DControl_Check::G_controlsizex()
{
	return G_sizeunit();
}

double T3DControl_Check::G_controlsizey()
{
	return G_sizeunit();
}


bool T3DControl_Check::UI_OnKeyDown(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch==VK_RETURN)
	{
		checked->copyfrom(!checked->G_val());
		Set_wasmodified();
		return true;
	}
	return false;
}

bool T3DControl_Check::UI_OnChar(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch=='-')
	{
		checked->copyfrom(false);
		Set_wasmodified();
		return true;
	}
	if (ch=='+')
	{
		checked->copyfrom(true);
		Set_wasmodified();
		return true;
	}
	return false;
}


void T3DControl_Check::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=G_offset();
	double sx=G_sizeunit();
	double sy=G_sizeunit();


	if (checked->G_val())
	{
		glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
		glLineWidth(2.0f);
		glBegin(GL_LINES);
		glVertex3d(x0,y0,z0);
		glVertex3d(x0+sx,y0+sy,z0);
		glVertex3d(x0+sx,y0,z0);
		glVertex3d(x0,y0+sy,z0);
		glEnd();
	}


	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	render_frame(x0,y0,sx,sy,z0+G_offset());
}



/////////////////////////////////////////////////////////////
// T3DControl_Button
/////////////////////////////////////////////////////////////


T3DControl_Button::T3DControl_Button(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	sizex=addparam(_qstr("SizeX"),SC_valname_scalar)->content.G_content_scalar();
	content=addparam(_qstr("Content"),SC_valname_string)->content.G_content_string();
}

T3DControl_Button::~T3DControl_Button()
{
}


double T3DControl_Button::G_controlsizex()
{
	return sizex->G_val();
}

double T3DControl_Button::G_controlsizey()
{
	return G_sizeunit();
}


bool T3DControl_Button::UI_OnKeyDown(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch==VK_RETURN)
	{
		Set_wasmodified();
		return true;
	}
	return false;
}



void T3DControl_Button::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=G_offset();
	double sx=sizex->G_val();
	double sy=G_sizeunit();



	QString str;
	content->tostring(str,0);

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	rc->rendertext(DEFAULT_FONT,&Tvertex(x0+sy/5,y0+sy/4,z0),
		&Tvector(G_textsize(),0,0),
		&Tvector(0,G_textsize(),0),str,0);

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());

	double lx=sx;double ly=sy;
	double oo=sy/5;
	glLineWidth(2.0f);
	glBegin(GL_LINE_LOOP);
	glVertex3d(x0+oo,y0,z0);
	glVertex3d(x0+lx-oo,y0,z0);
	glVertex3d(x0+lx,y0+oo,z0);
	glVertex3d(x0+lx,y0+ly-oo,z0);
	glVertex3d(x0+lx-oo,y0+ly,z0);
	glVertex3d(x0+oo,y0+ly,z0);
	glVertex3d(x0,y0+ly-oo,z0);
	glVertex3d(x0,y0+oo,z0);
	glEnd();

	//render_frame(x0,y0,sx,sy,z0+G_offset());
}




/////////////////////////////////////////////////////////////
// T3DControl_List
/////////////////////////////////////////////////////////////


T3DControl_List::T3DControl_List(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols)
{
	sizex=addparam(_qstr("SizeX"),SC_valname_scalar)->content.G_content_scalar();

	list=G_valuecontent<TSC_list>(&addparam(_qstr("List"),SC_valname_list)->content);

	selectidx=addparam(_qstr("SelectIdx"),SC_valname_scalar)->content.G_content_scalar();
	selectidx->copyfrom(0.0);

	county=addparam(_qstr("CountY"),SC_valname_scalar)->content.G_content_scalar();
	county->copyfrom(4);

	offset=0;

}

T3DControl_List::~T3DControl_List()
{
}

TSC_value* T3DControl_List::G_selecteditem()
{
	return list->get(selectidx->G_intval());
}



double T3DControl_List::G_controlsizex()
{
	return sizex->G_val();
}

double T3DControl_List::G_controlsizey()
{
	return G_sizeunit()*county->G_val();
}


void T3DControl_List::render_impl(Trendercontext *rc, const TObjectRenderStatus *status)
{
	QString str;

	double x0=G_controlposx();
	double y0=G_controlposy();
	double z0=G_offset();
	double sx=sizex->G_val();

	TSC_color *backcol=G_scene()->G_backcolor();


	int linecount=county->G_intval();
	double unity=G_sizeunit();

	for (int i=0; i<list->G_size(); i++)
		if ((i-offset>=0)&&(i-offset<linecount))
		{
			double yps=y0+unity/10+unity*(linecount-1-(i-offset));
			if (i==selectidx->G_intval())
			{
				glColor4d((rendercolor.G_R()+backcol->G_R())/2,(rendercolor.G_G()+backcol->G_G())/2,(rendercolor.G_B()+backcol->G_B())/2,(rendercolor.G_A()+backcol->G_A())/2);
				render_rect(x0,yps,sx,unity,z0);
			}
			list->get(i)->tostring(str);
			glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
			rc->rendertext(DEFAULT_FONT,&Tvertex(x0+unity/10,yps+unity/4,z0+G_offset()),
				&Tvector(G_textsize(),0,0),
				&Tvector(0,G_textsize(),0),str,0);
		}

	glColor4d(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());
	render_frame(x0,y0,sx,unity*linecount,z0+G_offset());
}


bool T3DControl_List::UI_OnPressed_Up()
{
	if (selectidx->G_val()>0)
	{
		selectidx->copyfrom(selectidx->G_intval()-1);
		paramchanged(_qstr(""));
		Set_wasmodified();
		return true;
	}
	return false;
}

bool T3DControl_List::UI_OnPressed_Down()
{
	if (selectidx->G_val()<list->G_size()-1)
	{
		selectidx->copyfrom(selectidx->G_intval()+1);
		paramchanged(_qstr(""));
		Set_wasmodified();
		return true;
	}
	return false;
}

bool T3DControl_List::UI_OnChar(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch=='-') return UI_OnPressed_Up();
	if (ch=='+') return UI_OnPressed_Down();
	return false;
}


void T3DControl_List::paramchanged(StrPtr iname)
{
	if (offset>selectidx->G_val()) offset=selectidx->G_val();
	if (offset<=selectidx->G_val()-county->G_val()) offset=selectidx->G_val()-county->G_val()+1;
	if (offset<0) offset=0;
}



/////////////////////////////////////////////////////////////
// T3DControl_Menu
/////////////////////////////////////////////////////////////


void T3DControl_Menu_Item::additem(StrPtr iID, StrPtr iname, bool cancheck)
{
	T3DControl_Menu_Item *it=new T3DControl_Menu_Item(this);subitems.add(it);
	it->ID=iID;
	it->name=iname;
	it->cancheck=cancheck;
}


T3DControl_Menu_Item* T3DControl_Menu_Item::finditem(StrPtr iID)
{
	if (issame(iID,ID)) return this;
	for (int i=0; i<subitems.G_count(); i++)
	{
		T3DControl_Menu_Item *rs=subitems[i]->finditem(iID);
		if (rs!=NULL) return rs;
	}
	return NULL;
}


T3DControl_Menu::T3DControl_Menu(T3DScene *iscene, bool addtocontrols) : T3DControl(iscene,addtocontrols) , root(NULL)
{
	sizex=addparam(_qstr("SizeX"),SC_valname_scalar)->content.G_content_scalar();
	selectid=addparam(_qstr("SelectID"),SC_valname_string)->content.G_content_string();
	root.cursubsel=0;

}

T3DControl_Menu::~T3DControl_Menu()
{
}

void T3DControl_Menu::additem(StrPtr iID, StrPtr iname, StrPtr parentid, bool cancheck)
{
	T3DControl_Menu_Item *parent=&root;
	if (qstrlen(parentid)>0)
	{
		parent=root.finditem(parentid);
		if (parent==NULL)
		{
			QString err;FormatString(err,_text("Invalid parent menu ID '^1'"),parentid);
			throw QError(err);
		}
	}
	parent->additem(iID,iname,cancheck);
}


T3DControl_Menu_Item* T3DControl_Menu::G_selitem()
{
	T3DControl_Menu_Item *it=&root;
	bool finished=false;
	while (!finished)
	{
		if ((it->cursubsel>=0)&&(it->cursubsel<it->subitems.G_count()))
			it=it->subitems[it->cursubsel];
		else finished=true;
	}
	return it;
}


void T3DControl_Menu::rendermenu(T3DControl_Menu_Item *parentitem, Trendercontext *rc, double x0, double y0)
{
	TQXColor col_foreground(rendercolor.G_R(),rendercolor.G_G(),rendercolor.G_B(),rendercolor.G_A());

	TSC_color *backcol=G_scene()->G_backcolor();
	TQXColor col_background(backcol->G_R(),backcol->G_G(),backcol->G_B(),backcol->G_A());

	TQXColor col_menuback=6*col_background+col_foreground;

	TQXColor col_menubacksel=1.5*col_background+col_foreground;

	TQXColor col_menubackactivesel=col_menubacksel+0.5*TQXColor(1,0,0);

	double lineh=G_sizeunit();
	double z0=G_offset();
	double sx=sizex->G_val();
	double yp=y0;
	for (int i=0; i<parentitem->subitems.G_count(); i++)
	{
		T3DControl_Menu_Item *item=parentitem->subitems[i];

		glColor4d(col_menuback.G_r(),col_menuback.G_g(),col_menuback.G_b(),col_menuback.G_a());
		if (i==parentitem->cursubsel)
		{
			glColor4d(col_menubacksel.G_r(),col_menubacksel.G_g(),col_menubacksel.G_b(),col_menubacksel.G_a());
			if (G_isactive())
				glColor4d(col_menubackactivesel.G_r(),col_menubackactivesel.G_g(),col_menubackactivesel.G_b(),col_menubackactivesel.G_a());
		}

		render_rect(x0,yp-lineh,sx,lineh,z0);

		glColor4d(col_foreground.G_r(),col_foreground.G_g(),col_foreground.G_b(),col_foreground.G_a());
		rc->rendertext(DEFAULT_FONT,&Tvertex(x0+0.7*lineh,yp-lineh+lineh/4,z0+G_offset()),
			&Tvector(G_textsize(),0,0),
			&Tvector(0,G_textsize(),0),item->name,0);

		if (item->checked)
		{
			double oo=lineh/6;
			glLineWidth(2.0f);
			glBegin(GL_LINE_STRIP);
			glVertex3d(x0+lineh/4-oo,yp-lineh+0.4*lineh+oo,z0);
			glVertex3d(x0+lineh/4,yp-lineh+0.4*lineh,z0);
			glVertex3d(x0+lineh/4+2*oo,yp-lineh+0.4*lineh+2*oo,z0);
			glEnd();
		}

		if (item->subitems.G_count()>0)
		{
			double oo=lineh/4;
			glLineWidth(2.0f);
			glBegin(GL_LINE_STRIP);
			glVertex3d(x0+sx-oo/2-oo,yp-lineh+lineh/2-oo,z0);
			glVertex3d(x0+sx-oo/2,yp-lineh+lineh/2,z0);
			glVertex3d(x0+sx-oo/2-oo,yp-lineh+lineh/2+oo,z0);
			glEnd();
		}

		if (i==parentitem->cursubsel) rendermenu(item,rc,x0+sx+lineh/10,yp);

		yp-=lineh;
	}
}


void T3DControl_Menu::render(Trendercontext *rc, const TObjectRenderStatus *status, bool isrecording)
{
	if (!G_isvisible()) return;
	if (!rc->G_viewport()->G_showcontrols()) return;
	if (!G_3DCosmos().G_showcontrols()) return;

	rendermenu(&root,rc,G_controlposx(),G_controlposy());
}


void T3DControl_Menu::setselectid()
{
	T3DControl_Menu_Item *selitem=G_selitem();
	selectid->fromstring(selitem->ID);
}

bool T3DControl_Menu::UI_OnPressed_Up()
{
	T3DControl_Menu_Item *selitem=G_selitem();
	if (selitem->parent!=NULL)
	{
		selitem->parent->cursubsel=(selitem->parent->cursubsel-1+selitem->parent->subitems.G_count())%selitem->parent->subitems.G_count();
		setselectid();
	}
	return true;
}

bool T3DControl_Menu::UI_OnPressed_Down()
{
	T3DControl_Menu_Item *selitem=G_selitem();
	if (selitem->parent==NULL)
	{
		if (root.subitems.G_count()>0)
		{
			root.cursubsel=0;
			setselectid();
		}
	}
	else
	{
		selitem->parent->cursubsel=(selitem->parent->cursubsel+1)%selitem->parent->subitems.G_count();
		setselectid();
	}
	return true;
}

bool T3DControl_Menu::UI_OnKeyDown(UINT ch, bool shiftpressed, bool controlpressed)
{
	T3DControl_Menu_Item *selitem=G_selitem();
	if ((ch==VK_LEFT)&&(shiftpressed)&&(!controlpressed))
	{
		if ((selitem->parent!=NULL)&&(selitem->parent->parent!=NULL))
		{
			selitem->parent->cursubsel=-1;
			setselectid();
			return true;
		}
	}
	if ((ch==VK_RIGHT)&&(shiftpressed)&&(!controlpressed))
	{
		if (selitem->subitems.G_count()>0)
		{
			selitem->cursubsel=0;
			setselectid();
			return true;
		}
	}

	if ((ch==VK_TAB)&&(!shiftpressed)&&(!controlpressed)) return UI_OnKeyDown(VK_RIGHT,true,false);
	if ((ch==VK_TAB)&&( shiftpressed)&&(!controlpressed)) return UI_OnKeyDown(VK_LEFT,true,false);

	if (ch==VK_RETURN)
	{
		if (selitem!=NULL)
		{
			if (selitem->cancheck) selitem->checked=!selitem->checked;
			setselectid();
			Set_wasmodified();
			return true;
		}
	}

	return false;
}


bool T3DControl_Menu::UI_OnChar(UINT ch, bool shiftpressed, bool controlpressed)
{
	if (ch=='-') return UI_OnPressed_Up();
	if (ch=='+') return UI_OnPressed_Down();
	return false;
}




void T3DControl_Menu::paramchanged(StrPtr iname)
{
/*	if (offset>selectidx->G_val()) offset=selectidx->G_val();
	if (offset<=selectidx->G_val()-county->G_val()) offset=selectidx->G_val()-county->G_val()+1;
	if (offset<0) offset=0;*/
}



///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_control_list_getselection,Selected)
{
	setreturntype(SC_valname_any);
	setmemberfunction(SC_valname_control_list);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DControl_List *list=G_valuecontent<T3DControl_List>(owner);
	retval->copyfrom(list->G_selecteditem());
}
ENDFUNCTION(func_control_list_getselection)


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_control_select,ActivateControl)
{
	addvar(_qstr("control"),SC_valname_any);
	extendclasspath(SC_treeclass_controls);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DControl *ctrl=(T3DControl*)(arglist->get(0)->G_content());
	G_3DCosmos().controls_activate(ctrl);
//	T3DControl_List *list=G_valuecontent<T3DControl_List>(owner);
//	retval->copyfrom(list->G_selecteditem());
}
ENDFUNCTION(func_control_select)



///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_control_menu_additem,Add)
{
	setmemberfunction(SC_valname_control_menu);
	addvar(_qstr("ParentID"),SC_valname_string);
	addvar(_qstr("Content"),SC_valname_string);
	addvar(_qstr("ID"),SC_valname_string,false);
	addvar(_qstr("CanCheck"),SC_valname_boolean,false);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DControl_Menu *menu=G_valuecontent<T3DControl_Menu>(owner);
	QString parentid=arglist->get(0)->G_content_string()->G_string();
	QString name=arglist->get(1)->G_content_string()->G_string();
	QString id=name;
	if (arglist->G_ispresent(2))
		id=arglist->get(2)->G_content_string()->G_string();
	bool cancheck=false;
	if (arglist->G_ispresent(3)) cancheck=arglist->get(3)->G_content_boolean()->G_val();
	menu->additem(id,name,parentid,cancheck);
}
ENDFUNCTION(func_control_menu_additem)


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_control_menu_ischecked,Checked)
{
	setmemberfunction(SC_valname_control_menu);
	addvar(_qstr("ID"),SC_valname_string);
	setreturntype(SC_valname_boolean);
	setcanassign();
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	T3DControl_Menu *menu=G_valuecontent<T3DControl_Menu>(owner);
	QString id=arglist->get(0)->G_content_string()->G_string();
	T3DControl_Menu_Item *item=menu->root.finditem(id);
	if (item==NULL) throw QError(_text("Invalid menu item ID"));
	if (assigntoval!=NULL)
		item->checked=assigntoval->G_content_boolean()->G_val();
	retval->G_content_boolean()->copyfrom(item->checked);
}
ENDFUNCTION(func_control_menu_ischecked)


