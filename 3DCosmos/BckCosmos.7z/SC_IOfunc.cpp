#include "stdafx.h"

#include "qerror.h"

#include "valnames.h"

#include "utils.h"
#include "qfile.h"

#include "SC_func.h"
#include "SC_script.h"
#include "SC_env.h"

//#include "3Dscene.h"


#define filefunctions _qstr("Input / Output;Files")


///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_readtextfile,readtextfile)
{
	setclasspath(filefunctions);
	setreturntype(SC_valname_string);
	addvar(_qstr("filename"),SC_valname_string);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	QString content,line;
	StrPtr filename=arglist->get(0)->G_content_string()->G_string();
	QTextfile fl;
	fl.openread(filename);
	while (!fl.isend())
	{
		fl.readline(line);
		content+=line;
		content+=_qstr("\n");
	}
	fl.close();
	retval->G_content_string()->fromstring(content);
}
ENDFUNCTION(func_readtextfile)



///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_writetextfile,writetextfile)
{
	setclasspath(filefunctions);
	setreturntype(SC_valname_string);
	addvar(_qstr("filename"),SC_valname_string);
	addvar(_qstr("content"),SC_valname_string);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	StrPtr filename=arglist->get(0)->G_content_string()->G_string();
	StrPtr content=arglist->get(1)->G_content_string()->G_string();
	QTextfile fl;
	fl.openwrite(filename);
	fl.write(content);
	fl.close();
}
ENDFUNCTION(func_writetextfile)



///////////////////////////////////////////////////////////////////////////////////
FUNCTION(func_getfilelist,GetFileList)
{
	setclasspath(filefunctions);
	setreturntype(SC_valname_list);
	addvar(_qstr("wildcard"),SC_valname_string);
	addvar(_qstr("directories"),SC_valname_boolean,false);
}
void execute_implement(TSC_funcarglist *arglist, TSC_value *retval, TSC_value *assigntoval, TSC_value *owner)
{
	StrPtr wildcard=arglist->get(0)->G_content_string()->G_string();

	bool returndirs=false;
	if (arglist->G_ispresent(1)) returndirs=arglist->get(1)->G_content_boolean()->G_val();

	QFileFind filefind;
	filefind.start(wildcard);
	QString filename;
	bool isdir;
	TSC_list *list=G_valuecontent<TSC_list>(retval);
	list->reset();
	while (filefind.getnext(filename,isdir))
	{
		bool ok=false;
		if ((!returndirs)&&(!isdir)) ok=true;
		if ((returndirs)&&(isdir)) ok=true;
		if (ok)
		{
			TSC_value vl;
			vl.settype(GetTSCenv().G_datatype(SC_valname_string));
			vl.fromstring(filename);
			list->add(&vl);
		}
	}
}
ENDFUNCTION(func_getfilelist)
