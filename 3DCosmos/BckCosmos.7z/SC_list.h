#pragma once

#include "qbintagfile.h"

class TSC_list : public TObject
{
private:
	Tarray<TSC_value> items;
public:
	static StrPtr GetClassName() { return SC_valname_list; }
	TSC_list()
	{
	}
	void fromstring(StrPtr icontent)
	{
	}
	void tostring(QString &str, int tpe);
	static bool compare(TSC_list *val1, TSC_list *val2)
	{
		return false;
	}
	void operator=(const TSC_list &m);
	void add(const TSC_value *ival);
	void del(int nr);
	TSC_value* get(int nr);
	void grow(int cnt);
	void reset() { items.reset(); }
	int G_size() { return items.G_count(); }

	void streamout(QBinTagWriter &writer);
	void streamin(QBinTagReader &reader);


};
