#include "stdafx.h"

#include "qfile.h"

#include "astrotools.h"

#include "3DScene.h"

#include "3DStarGlobe.h"

#include "SC_script.h"
#include "SC_functor.h"

#include "gl/gl.h"
#include "gl/glu.h"
#include "gl/glaux.h"

StrPtr G_datadir();
StrPtr G_scriptsdir();
StrPtr G_texturesdir();


//******************************************************************
// T3DObjectStarGlobe
//******************************************************************

T3DObjectStarGlobe::T3DObjectStarGlobe(T3DScene *iscene) : T3DGeoObject(iscene)
{
	renderback->copyfrom(true);
	enablelight->copyfrom(false);

	blendtype->fromint(BlendTransparent);
	depthmask->fromint(DepthMaskDisable);


	radius=addparam(_qstr("Radius"),SC_valname_scalar)->content.G_content_scalar();
	starsize=addparam(_qstr("StarSize"),SC_valname_scalar)->content.G_content_scalar();
	starsize->copyfrom(0.01);

	conlinesize=addparam(_qstr("LineSize"),SC_valname_scalar)->content.G_content_scalar();conlinesize->copyfrom(0.0);
	conlinecolor=G_valuecontent<TSC_color>(&addparam(_qstr("LineColor"),SC_valname_color)->content);conlinecolor->copyfrom(0,0,1,0.5);



	calculated=false;

/*	isclosed=addparam(_qstr("IsClosed"),SC_valname_boolean)->content.G_content_boolean();
	isclosed->copyfrom(false);*/

//	curverendertype=&addparam(SC_valname_curverendertype,SC_valname_curverendertype)->content;

}


void T3DObjectStarGlobe::load()
{
	//read stars

	stars_MAG.reset();
	stars_X.reset();
	stars_Y.reset();
	stars_Z.reset();
	dir1_X.reset();dir1_Y.reset();dir1_Z.reset();
	dir2_X.reset();dir2_Y.reset();dir2_Z.reset();

	QString line,part;
	double ra,dec,mag,e1,e2;
	QString filename=G_datadir();
	filename+=_qstr("\\AstroData\\stars1.txt");
	QTextfile fp;
	fp.openread(filename);
	fp.readline(line);
	while (!fp.isend())
	{
		fp.readline(line);
		line.splitstring(_qstr("\t"),part);ra=qstr2double(part);
		line.splitstring(_qstr("\t"),part);dec=qstr2double(part);
		line.splitstring(_qstr("\t"),part);mag=qstr2double(part);
		ra=ra*deg2rad;
		dec=dec*deg2rad;
		stars_MAG.add(mag);
		equat2eclipt(ra,dec,e1,e2);
		stars_X.add(cos(e1)*cos(e2));
		stars_Y.add(sin(e1)*cos(e2));
		stars_Z.add(sin(e2));
//		stars_X.add(cos(e1)*cos(e2));
//		stars_Z.add(-sin(e1)*cos(e2));
//		stars_Y.add(sin(e2));
	}
	fp.close();


	double d1x,d1y,d1z,r,d2x,d2y,d2z;
	for (int i=0; i<stars_X.G_count(); i++)
	{
		d1x=-stars_Y[i];d1y=stars_X[i];r=sqrt(d1x*d1x+d1y*d1y);
		d1x/=r;d1y/=r;d1z=0;
		d2x=d1y*stars_Z[i];d2y=-d1x*stars_Z[i];d2z=stars_Y[i]*d1x-stars_X[i]*d1y;
		r=sqrt(d2x*d2x+d2y*d2y+d2z*d2z);
		d2x/=r;d2y/=r;d2z/=r;
		dir1_X.add(d1x);dir1_Y.add(d1y);dir1_Z.add(d1z);
		dir2_X.add(d2x);dir2_Y.add(d2y);dir2_Z.add(d2z);
	}


	//read constellation lines

	int a1,a2,d1,d2;

	QString st1;
	filename=G_datadir();
	filename+=_qstr("\\AstroData\\conlines.txt");
	fp.openread(filename);
//	fp.readline(line);
	while (!fp.isend())
	{
		fp.readline(line);

		if (qstrlen(line)>4)
		{
			line.splitstring(_qstr(","),st1);

			line.splitstring(_qstr(","),st1);a1=qstr2int(st1);
			line.splitstring(_qstr(","),st1);d1=qstr2int(st1);
			line.splitstring(_qstr(","),st1);a2=qstr2int(st1);
			line.splitstring(_qstr(","),st1);d2=qstr2int(st1);
			ra=a1/1000.0*15*deg2rad;
			dec=d1/100.0*deg2rad;
			equat2eclipt(ra,dec,e1,e2);
			const_X_1.add(cos(e1)*cos(e2));
			const_Y_1.add(sin(e1)*cos(e2));
			const_Z_1.add(sin(e2));
//			const_X_1.add(cos(e1)*cos(e2));
//			const_Z_1.add(-sin(e1)*cos(e2));
//			const_Y_1.add(sin(e2));
			ra=a2/1000.0*15*deg2rad;
			dec=d2/100.0*deg2rad;
			equat2eclipt(ra,dec,e1,e2);
			const_X_2.add(cos(e1)*cos(e2));
			const_Y_2.add(sin(e1)*cos(e2));
			const_Z_2.add(sin(e2));
//			const_X_2.add(cos(e1)*cos(e2));
//			const_Z_2.add(-sin(e1)*cos(e2));
//			const_Y_2.add(sin(e2));
		}
	}
	fp.close();


}

void T3DObjectStarGlobe::init()
{
	load();
}

void T3DObjectStarGlobe::calculate()
{
	double x0,y0,z0,gr,fc;
	double hx,hy,hz,vx,vy,vz;
	T4color col2;

	double rd=radius->G_val();
	double ssize=starsize->G_val();

	if (calculated) return;

	//for stars

	starvertexbuffer.reset();starcolorbuffer.reset();startexturebuffer.reset();
	for (int i=0; i<stars_X.G_count(); i++)
	{
		x0=stars_X[i]*rd;
		y0=stars_Y[i]*rd;
		z0=stars_Z[i]*rd;
		gr=(7-stars_MAG[i])/7;
		gr=sqrt(gr);
		if (gr<0.15) gr=0.15;
		if (gr>1.0) gr=1.0;
		fc=ssize*gr;
		hx=dir1_X[i]*fc;hy=dir1_Y[i]*fc;hz=dir1_Z[i]*fc;
		vx=dir2_X[i]*fc;vy=dir2_Y[i]*fc;vz=dir2_Z[i]*fc;

		col2.r=gr*color->G_R();
		col2.g=gr*color->G_G();
		col2.b=gr*color->G_B();
		col2.a=1*color->G_A();

		startexturebuffer.add(T2textureidx(0,0));
		starvertexbuffer.add(Tvec3d(x0-hx-vx,y0-hy-vy,z0-hz-vz));

		startexturebuffer.add(T2textureidx(0,1));
		starvertexbuffer.add(Tvec3d(x0-hx+vx,y0-hy+vy,z0-hz+vz));

		startexturebuffer.add(T2textureidx(1,1));
		starvertexbuffer.add(Tvec3d(x0+hx+vx,y0+hy+vy,z0+hz+vz));

		startexturebuffer.add(T2textureidx(1,0));
		starvertexbuffer.add(Tvec3d(x0+hx-vx,y0+hy-vy,z0+hz-vz));


		starcolorbuffer.add(col2);starcolorbuffer.add(col2);starcolorbuffer.add(col2);starcolorbuffer.add(col2);
	}

	//for constellation lines
	conlinesvertexbuffer.reset();
	conlinestexturebuffer.reset();

	double linesize=conlinesize->G_val();
	Tvec3d ps1,ps2,dr1,dr2,ps1a,ps1b,ps2a,ps2b;
	if (linesize>1.0e-9)
	{
		for (int i=0; i<const_X_1.G_count(); i++)
		{
			ps1=Tvec3d(rd*const_X_1[i],rd*const_Y_1[i],rd*const_Z_1[i]);
			ps2=Tvec3d(rd*const_X_2[i],rd*const_Y_2[i],rd*const_Z_2[i]);
			dr1.lincomb(ps2,ps1,+1,-1);dr1.norm();
			dr2.vecprod(ps1,dr1);dr2.norm();
			ps1a.lincomb(ps1,dr2,1,-linesize/2);
			ps1b.lincomb(ps1,dr2,1,+linesize/2);
			ps2a.lincomb(ps2,dr2,1,-linesize/2);
			ps2b.lincomb(ps2,dr2,1,+linesize/2);
			conlinesvertexbuffer.add(ps1a);conlinestexturebuffer.add(T2textureidx(0,0));
			conlinesvertexbuffer.add(ps2a);conlinestexturebuffer.add(T2textureidx(0,0));
			conlinesvertexbuffer.add(ps2b);conlinestexturebuffer.add(T2textureidx(1,1));
			conlinesvertexbuffer.add(ps1b);conlinestexturebuffer.add(T2textureidx(1,1));
		}
	}


	calculated=true;
}

void T3DObjectStarGlobe::precalcrender_exec(Tprecalcrendercontext *pre)
{
	calculate();
}


void T3DObjectStarGlobe::render_exec(Trendercontext *rc)
{
	//stars
	glEnableClientState(GL_VERTEX_ARRAY);
	glVertexPointer(3,GL_FLOAT,0,starvertexbuffer.G_ptr());

	glEnableClientState(GL_TEXTURE_COORD_ARRAY);
	glTexCoordPointer(2,GL_FLOAT,0,startexturebuffer.G_ptr());

	glEnableClientState(GL_COLOR_ARRAY);
	glColorPointer(4,GL_FLOAT,0,starcolorbuffer.G_ptr());

	glDrawArrays(GL_QUADS,0,starvertexbuffer.G_count());

	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	glDisableClientState(GL_COLOR_ARRAY);

	//constellation lines
	if (conlinesvertexbuffer.G_count()>0)
	{
		glEnableClientState(GL_VERTEX_ARRAY);
		glVertexPointer(3,GL_FLOAT,0,conlinesvertexbuffer.G_ptr());

		glEnableClientState(GL_TEXTURE_COORD_ARRAY);
		glTexCoordPointer(2,GL_FLOAT,0,conlinestexturebuffer.G_ptr());

		rc->set_color(conlinecolor->G_R()*color->G_R(),conlinecolor->G_G()*color->G_G(),conlinecolor->G_B()*color->G_B(),conlinecolor->G_A()*color->G_A());
		glDrawArrays(GL_QUADS,0,conlinesvertexbuffer.G_count());

		glDisableClientState(GL_VERTEX_ARRAY);
		glDisableClientState(GL_TEXTURE_COORD_ARRAY);
	}



}


void T3DObjectStarGlobe::paramchanged(StrPtr iname)
{
	calculated=false;
}
