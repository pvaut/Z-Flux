

void svdcmp (double **a, int m, int n, double w[], double **v);
