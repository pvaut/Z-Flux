#pragma once
#include "tools.h"
#include "qstring.h"
#include "objecttree.h"

#include "SC_value.h"
#include "SC_boolean.h"
#include "SC_color.h"
#include "SC_time.h"

#include "3Dscene.h"
#include "3Dviewport.h"
#include "3Dtexture.h"
#include "3Dmotion.h"
#include "3Dvideo.h"
#include "3Dvolshadow.h"

#include "joystick.h"

#define axiscount 6
#define axislevelcount 3

#define MAX_JOYSTICKCOUNT 2



class T3DScene;
class T3DSubFrameObject;
class T3DRenderViewport;
class Trendercontex;
class Tprecalcrendercontext;
class Tprecalcrendershadowvolumecontext;
class TObjectRenderStatus;
class T3DMotionFree;
class T3DControl;

class T3DObject : public TObjectTreeItem
{
private:
	TSC_boolean *isobjvisible;
protected:
	T3DScene *scene;
	T3DCosmos *cosmos;
	T3DSubFrameObject *parentframe;
public:
	T3DObject(T3DScene *iscene);
	virtual ~T3DObject();
	virtual StrPtr G_classname()=0;
	virtual void G_sourcecodename(QString &str);//name as it should be copied to the source code
	T3DScene* G_scene() { return scene; }
	void Set_parentframe(T3DSubFrameObject *iparentframe) { parentframe=iparentframe; }
	void Set_scene(T3DScene *iscene) { scene=iscene; }
	virtual T3DObject* findobject(TObjectTreeItem *treeitem);
	bool G_isvisible() { return isobjvisible->G_val(); }
public:
	T3DObject* MakeInstance();
	virtual T3DObject* CreateInstance()=0;
	virtual bool G_acceptsubobjects() { return false; }
	virtual void addsubobject(T3DObject *iobject) {};
	virtual T3DSubFrameObject *G_parentframe() { return parentframe; }
	virtual TObjectTreeItem *G_parent();

	virtual void execute_functor_prerenderaction() {}

	virtual void adjusttime(double timestep) {}
	virtual bool G_cancache() { return true; }
	virtual bool G_needrecache() { return isdirty; }//returns true of the cache of this object is outdated e.g. because of a parameter change

	//called once when object is created:
	virtual void init() {}

	//NOTE: precalcrender(2) can alter the object's state (never called multithreaded)
	virtual void precalcrender(Tprecalcrendercontext *pre) {}// common for all viewports
	virtual void precalcrender2(T3DRenderViewport *rvp, Tprecalcrendercontext *pre) {}// per viewport, common for left-right

	//NOTE: render should not alter the object's state (use for multithreaded rendering)
	virtual void render(Trendercontext *rc, const TObjectRenderStatus *renderstatus, bool isrecording) {}

	virtual void calcshadowvolumes(Tshadowvolumecontext *svc, T3DSubFrameObject *parentsubframe) {}
};




class T3DViewportlist : public TObjectTreeItem
{
	friend class T3DCosmos;
private:
	Tarray<T3DViewport> viewports;
public:
	T3DViewportlist()
	{
		param_readonly(_qstr("Name"),true);
	}
public:
	virtual StrPtr G_classname() { return _qstr("Viewports"); }
	void G_name(QString &str) { str=G_classname(); }
	int G_childcount();
	TObjectTreeItem* G_child(int nr);
	void delchild(TObjectTreeItem *ichild);
	T3DViewport* addviewport();
	void reset();
};


class T3DVideolist : public TObjectTreeItem
{
	friend class T3DCosmos;
private:
	Tarray<T3DVideo> videos;
public:
	T3DVideolist()
	{
		param_readonly(_qstr("Name"),true);
	}
public:
	virtual StrPtr G_classname() { return _qstr("Videos"); }
	void G_name(QString &str) { str=G_classname(); }
	int G_childcount();
	TObjectTreeItem* G_child(int nr);
	void delchild(TObjectTreeItem *ichild);
	T3DVideo* addvideo();
	void reset();
	void loadcurframes();
};





class T3DCosmos : public TObjectTreeItem
{
private:
	Tarray<T3DObject> objectcatalog;
	Tarray<T3DScene> scenes;
	T3DViewportlist viewportlist;
	T3DVideolist videolist;
	TSC_time *curtime;
	TSC_scalar *timespeed;//in seconds
	TSC_boolean *pauzed,*showcontrols;
	Tjoystickinfo joysticks[MAX_JOYSTICKCOUNT];
private:
	TSC_value *rendertype;//type: SC_valname_rendertype
	TSC_scalar *vsynccount,*requestedframerate;
	__int64 lastrendercounter;
	double rendertimerfreq;
	DWORD timingtest_lasttick;
	int timingtest_count;
	double timingtest_framerate;
public:
	static StrPtr GetClassName() { return SC_valname_objectroot; }
	virtual StrPtr G_classname() { return SC_valname_objectroot; }
	virtual void G_sourcecodename(QString &str) {str=_qstr("root"); };//name as it should be copied to the source code
	T3DCosmos();
	~T3DCosmos();
	void initvalues();
	void cleanup();
	void resetall();
	void resetallscenes();
	void resetallviewports();
	void resetallvideos();
	int G_objectcatalog_count() { return objectcatalog.G_count(); }
	T3DObject* G_objectcatalog_object(int nr) { return objectcatalog[nr]; }
	T3DObject* G_objectcatalog_object(StrPtr tpename);
	int G_rendertype() { return rendertype->toint(); }
	int G_vsynccount() { return vsynccount->G_intval(); }
	double G_requestedframerate() { return requestedframerate->G_val(); }
public:
	int G_childcount();
	TObjectTreeItem* G_child(int nr);
	virtual void delchild(TObjectTreeItem *ichild);
	T3DObject* findobject(TObjectTreeItem *treeitem);
	T3DScene* findscene(TObjectTreeItem *treeitem);

public:
	T3DScene* addscene();
	void delscene(int scenenr);
	int G_scenecount() { return scenes.G_count(); }
	T3DScene* G_scene(int nr) { return scenes[nr]; }
	T3DScene* G_scene(StrPtr name);

	virtual void paramchanged(StrPtr iname);

public:
	T3DViewportlist* G_viewportlist() { return &viewportlist; }
	int G_viewportcount() { return viewportlist.viewports.G_count(); }
	T3DViewport* G_viewport(int nr) { return viewportlist.viewports[nr]; }
	T3DViewport* G_selviewport()
	{
		if (G_viewportcount()<=0) return NULL;
		return viewportlist.viewports[0];
	}
public:
	T3DVideolist* G_videolist() { return &videolist; }

private://functions for UI axis: 0=X 1=Y 2=Z
	double axisposit[axiscount][axislevelcount];//idx1=axis idx2=level
public:
	void dispatchjoysticks();
	void updateaxisposit();
	bool G_axisactive(int axisnr, int axislevel);
	double G_axisposit(int axisnr, int axislevel);
	void UIaction_axis(int axisnr, int axislevel, double val);//this function is called if a user performs an action
	Tjoystickinfo& G_joystickinfo(int ID);

public:
	static T3DCosmos& Get()
	{
		static T3DCosmos sset;
		return sset;
	}

	void UI_OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	void UI_OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	void UI_processkey(UINT nChar, bool controlpressed, bool shiftpressed);

public:
	bool showdepthlayers,showstereogrid,showinfoline;
private:
	bool requeststop;
public:
	void Reset_requeststop();
	void Set_requeststop();
	bool G_requeststop();

	void releaseallcontexts();//called at the end of a script, to release all contexts from that thread

	void modify_timespeed(double ifactor);
	void pauze(bool ipauzed);
	bool G_pauzed();
	void adjusttimes(double timestep);
	void incrtime();
	void waitforframerate();
	void render();
	double G_framerate() { return timingtest_framerate; }
	const TSC_time* G_time() { return curtime; }

	void cmd_switchstereo();


private:
	Tcopyarray<T3DMotion> motioncatalog;
	T3DMotionFree *defaultmotion;
public:
	void motioncatalog_add(T3DMotion *mt);
	void motioncatalog_remove(T3DMotion *mt);
	T3DMotion* G_defaultmotion() { return defaultmotion; }

private:
	Tcopyarray<T3DControl> controls;
	int activecontrol;
public:
	bool G_showcontrols() { return showcontrols->G_val(); }
	void controls_add(T3DControl *icontrol);
	void controls_del(T3DControl *icontrol);
	void controls_selectnext(int dir);
	void controls_activate(T3DControl *ctrl);
	T3DControl* G_activecontrol();


private:
	Tbaltree keyboardcodes_index;
	Tarray<CString> keyboardcodes_names;
	Tintarray keyboardcodes_vals;
	QString lastkeypressed;
public:
	void addkeyboardcode(StrPtr iname, int ival);
	void initkeyboardcodes();
	int G_keyboardcode(StrPtr iname);
	StrPtr G_keyboardname(int icode);
	StrPtr G_lastkeypressed() { return lastkeypressed; }


};

T3DCosmos& G_3DCosmos();