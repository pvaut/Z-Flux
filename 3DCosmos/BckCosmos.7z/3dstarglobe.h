#pragma once

#include "3dscene.h"
#include "3dmesh.h"
#include "3dtexture.h"

class Tvertex;
class TSC_functor;


class T3DObjectStarGlobe : public T3DGeoObject
{
protected:
	TSC_scalar *radius,*starsize,*conlinesize;
	TSC_color *conlinecolor;
private:
	Tdoublearray stars_MAG,stars_X,stars_Y,stars_Z,dir1_X,dir1_Y,dir1_Z,dir2_X,dir2_Y,dir2_Z;
	Tdoublearray const_X_1,const_X_2,const_Y_1,const_Y_2,const_Z_1,const_Z_2;
	bool calculated;
	Titemarray<Tvec3d> starvertexbuffer;
	Titemarray<T4color> starcolorbuffer;
	Titemarray<T2textureidx> startexturebuffer;
	Titemarray<Tvec3d> conlinesvertexbuffer;
	Titemarray<T2textureidx> conlinestexturebuffer;
public:
	T3DObjectStarGlobe(T3DScene *iscene=NULL);
	static StrPtr GetClassName() { return SC_valname_starglobe; }
	virtual StrPtr G_classname() { return SC_valname_starglobe; }
	virtual T3DObject* CreateInstance() { return new T3DObjectStarGlobe(NULL); }
	virtual void paramchanged(StrPtr iname);
public:
	void load();
	void calculate();
/*	bool G_isclosed() { return isclosed->G_val(); }
	int G_curverendertype() { return curverendertype->toint(); }
	void reset();
	void addpoint(Tvertex *pt);
	void close();
	void generate(TSC_functor *functor, double minv, double maxv, int count);
	void transform(const Taffinetransformation *transf);
	void makecircle(const Tvertex *center, const Tvector *normal, double radius, int resolution);
	virtual bool G_cancache();*/
public:
	virtual void init();
protected:
	void precalcrender_exec(Tprecalcrendercontext *pre);
	void render_exec(Trendercontext *rc);
};
