#include"stdafx.h"
#include"allBnScript.h"
