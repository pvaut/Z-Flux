#pragma once
#include "tools.h"
#include "qstring.h"
#include "objecttree.h"

#include "SC_value.h"

#include "renderwindow.h"

class T3DCosmos;
class TDisplayDevice;
class T3DScene;
class Tvideocapture;



class T3DViewport : public TObjectTreeItem
{
private:
	T3DCosmos *cosmos;
	TRenderWindow *leftwin,*rightwin;
	bool started,isstereo;
	Tvertex *camerapos;
	Tvector *cameradir,*cameraupdir;
	TSC_boolean *enableusernavigation,*enableusertimecontrol,*usestereo,*erasebackground,*showcontrols;
	TSC_scalar *xminfrac,*yminfrac,*xmaxfrac,*ymaxfrac;
	TSC_color *fadecolor;
	Taffinetransformation *transformation;
	int winxres,winyres;//only stored for informative reason (e.g. in function G_aspectratio)

public:
	struct{
		Tvector scenerot,cammove;
	} currentmove;

public:
	T3DViewport();
	~T3DViewport();
	static StrPtr GetClassName() { return SC_valname_viewport; }
	virtual StrPtr G_classname() { return SC_valname_viewport; }
	virtual void G_sourcecodename(QString &str);//name as it should be copied to the source code
public:
	virtual bool G_param_optionlist(StrPtr paramname, Tarray<QString> &list);
	virtual void paramchanged(StrPtr iname);
	virtual TObjectTreeItem *G_parent();
private:
	TSC_scalar *stretchfactor,*focaldistance,*eyeseparation,*aperture,*nearclipplane,*farclipplane,*framesize,*xoffsetfrac;//scalars
public:
	bool G_started() { return started; }
	bool G_isstereo() { return isstereo; }
	bool G_erasebackground() { return erasebackground->G_val(); }
	bool G_showcontrols() { return showcontrols->G_val(); }
	TRenderWindow* G_leftwin();
	TRenderWindow* G_rightwin();
	StrPtr G_attachedscenename();
	void resetparams();
	void resetcurrentmove();
	void applycurrentmove();
	void delfromscene();
	void start();
	void setscene(T3DScene *iscene);
public:
	double G_stretchfactor() { return stretchfactor->G_val(); }
	double G_eyeseparation();
	double G_focaldistance() { return focaldistance->G_val(); }
	double G_aperture() { return aperture->G_val(); }
	double G_nearclipplane() { return nearclipplane->G_val(); }
	double G_farclipplane() { return farclipplane->G_val(); }
	double G_cameramovestep() { return G_focaldistance()/50.0; }
	double G_xoffsetfrac() { return xoffsetfrac->G_val(); }

	double G_framesize() { return framesize->G_val(); }

	double G_xminfrac() { return xminfrac->G_val(); }
	double G_yminfrac() { return yminfrac->G_val(); }
	double G_xmaxfrac() { return xmaxfrac->G_val(); }
	double G_ymaxfrac() { return ymaxfrac->G_val(); }

	TSC_color* G_fadecolor() { return fadecolor; }

	double G_aspectratio();


	Tvertex* G_camerapos() { return camerapos; }
	Tvector* G_cameradir() { return cameradir; }
	Tvector* G_cameraupdir() { return cameraupdir; }
	Taffinetransformation* G_transformation() { return transformation; }
	bool G_enableusernavigation() { return enableusernavigation->G_val(); }
	bool G_enableusertimecontrol() { return enableusertimecontrol->G_val(); }

	void camera_rotatehor(double angle);
	void camera_rotatevert(double angle);
	void camera_move(double fc);
	void scene_rotatehor(double angle);
	void scene_rotatevert(double angle);
	void scene_move(double fc);
	void dispatchusernavigation();

	void switchcursoractive();
	void switchstereo();
	bool G_cursoractive();

private:
	Tvideocapture *videocapture;
public:
	void videocapture_start(StrPtr ifilename);
	void videocapture_stop();
	void videocapture_addframe();


};
