

/* this ALWAYS GENERATED file contains the IIDs and CLSIDs */

/* link this file in with the server and any clients */


 /* File created by MIDL compiler version 6.00.0366 */
/* at Tue Nov 11 18:16:21 2008
 */
/* Compiler settings for vc80.idl:
    Oicf, W1, Zp8, env=Win32 (32b run)
    protocol : dce , ms_ext, c_ext, robust
    error checks: allocation ref bounds_check enum stub_data 
    VC __declspec() decoration level: 
         __declspec(uuid()), __declspec(selectany), __declspec(novtable)
         DECLSPEC_UUID(), MIDL_INTERFACE()
*/
//@@MIDL_FILE_HEADING(  )

#pragma warning( disable: 4049 )  /* more than 64k source lines */


#ifdef __cplusplus
extern "C"{
#endif 


#include <rpc.h>
#include <rpcndr.h>

#ifdef _MIDL_USE_GUIDDEF_

#ifndef INITGUID
#define INITGUID
#include <guiddef.h>
#undef INITGUID
#else
#include <guiddef.h>
#endif

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        DEFINE_GUID(name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8)

#else // !_MIDL_USE_GUIDDEF_

#ifndef __IID_DEFINED__
#define __IID_DEFINED__

typedef struct _IID
{
    unsigned long x;
    unsigned short s1;
    unsigned short s2;
    unsigned char  c[8];
} IID;

#endif // __IID_DEFINED__

#ifndef CLSID_DEFINED
#define CLSID_DEFINED
typedef IID CLSID;
#endif // CLSID_DEFINED

#define MIDL_DEFINE_GUID(type,name,l,w1,w2,b1,b2,b3,b4,b5,b6,b7,b8) \
        const type name = {l,w1,w2,{b1,b2,b3,b4,b5,b6,b7,b8}}

#endif !_MIDL_USE_GUIDDEF_

MIDL_DEFINE_GUID(IID, IID_IAngleAxis,0x1ef2baff,0x54e9,0x4706,0x9f,0x61,0x07,0x8f,0x71,0x34,0xfd,0x35);


MIDL_DEFINE_GUID(IID, IID_IVector3D,0x8c2aa71d,0x2b23,0x43f5,0xa6,0xed,0x4d,0xf5,0x7e,0x9c,0xd8,0xd5);


MIDL_DEFINE_GUID(IID, IID_ISensor,0xf3a6775e,0x6fa1,0x4829,0xbf,0x32,0x5b,0x04,0x5c,0x29,0x07,0x8f);


MIDL_DEFINE_GUID(IID, IID_IKeyboard,0xd6f968e7,0x2993,0x48d7,0xaf,0x24,0x8b,0x60,0x2d,0x92,0x5b,0x2c);


MIDL_DEFINE_GUID(IID, IID_ISimpleDevice,0xcb3bf65e,0x0816,0x482a,0xbb,0x11,0x64,0xaf,0x1e,0x83,0x78,0x12);


MIDL_DEFINE_GUID(IID, IID_ITDxInfo,0x00612962,0x8fb6,0x47b2,0xbf,0x98,0x4e,0x8c,0x0f,0xf5,0xf5,0x59);


MIDL_DEFINE_GUID(IID, LIBID_Cosmos3D,0xfe993e16,0x9ec0,0x3221,0xb2,0xda,0xa9,0x11,0xd0,0xa3,0xc8,0x0b);


MIDL_DEFINE_GUID(IID, DIID__ISensorEvents,0xe6929a4a,0x6f41,0x46c6,0x92,0x52,0xa8,0xcc,0x53,0x47,0x2c,0xb1);


MIDL_DEFINE_GUID(IID, DIID__IKeyboardEvents,0x6b6bb0a8,0x4491,0x40cf,0xb1,0xa9,0xc1,0x5a,0x80,0x1f,0xe1,0x51);


MIDL_DEFINE_GUID(IID, DIID__ISimpleDeviceEvents,0x8fe3a216,0xe235,0x49a6,0x91,0x36,0xf9,0xd8,0x1f,0xda,0xde,0xf5);


MIDL_DEFINE_GUID(CLSID, CLSID___Impl__ISimpleDeviceEvents,0x5BB1322E,0x5E07,0x33DA,0xA5,0x87,0x15,0x9F,0xF8,0x7E,0xE3,0x76);


MIDL_DEFINE_GUID(CLSID, CLSID___Impl__ISensorEvents,0x79E329DD,0x66A0,0x3299,0xA4,0x6D,0x17,0xC7,0x6E,0x7B,0xD5,0x80);


MIDL_DEFINE_GUID(CLSID, CLSID___Impl__IKeyboardEvents,0xDFE48A04,0x131B,0x3D9F,0x85,0x36,0xBA,0x63,0xD8,0x74,0xCB,0x8A);

#undef MIDL_DEFINE_GUID

#ifdef __cplusplus
}
#endif



