#include "qstring.h"

void copyclipboard(StrPtr str);
bool pasteclipboard(QString &str);


double random();