#include "stdafx.h"

#include "afxdisp.h"

#include "qxwin.h"
#include "qxbuttonbar.h"
#include "qxscrollbar.h"
#include "qxgrid.h"
#include "qfile.h"
#include "main.h"

#include "3DScene.h"

#include "objecttreeview.h"
#include "objectpropertyview.h"
#include "formattedstringview.h"
#include "scriptsourceview.h"

#include "SC_functree.h"

#include "displaydevices.h"

#include "settingsdialog.h"


Tsettingsdialog::Tsettingsdialog(Tmainwin *iparent) 
: CDialog(IDD_SETTINGS,iparent)
{
	parent=iparent;
}

Tsettingsdialog::~Tsettingsdialog()
{
}


BOOL Tsettingsdialog::OnInitDialog()
{
	GetDlgItem(IDC_SCRIPTSDIR)->SetWindowText(G_scriptsdir());

	((CButton*)GetDlgItem(IDC_COLORSCHEME))->SetCheck(G_QXSys().colscheme_dark);

	CDialog::OnInitDialog();
	return TRUE;
}


void Tsettingsdialog::OnOK()
{
	CString cst;
	GetDlgItem(IDC_SCRIPTSDIR)->GetWindowText(cst);
	Set_scriptsdir(cst);
	QParamStore(PARAMLOCATION_REGISTRY,_qstr("ScriptsDirectory"),G_scriptsdir());

	G_QXSys().colscheme_dark=((CButton*)GetDlgItem(IDC_COLORSCHEME))->GetCheck();

	G_QXSys().writesettings();


	parent->invalidateall();
	CDialog::OnOK();
}
